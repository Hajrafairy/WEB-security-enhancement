const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const csrf = require('csurf');
const bcrypt = require('bcrypt');

const app = express();

// ================= MIDDLEWARE =================
app.use(cookieParser());
app.use(bodyParser.urlencoded({ extended: true }));

const csrfProtection = csrf({ cookie: true });

// ================= DATABASE =================
const db = new sqlite3.Database(':memory:');

db.serialize(() => {
    db.run("CREATE TABLE users (username TEXT, password TEXT)");

    // store plain password for testing SQLi step (you can change later)
    db.run("INSERT INTO users VALUES ('admin', '1234')");
});

// ================= LOGIN PAGE =================
app.get('/', (req, res) => {
    res.send(`
        <h2>Login Page</h2>
        <form method="POST" action="/login">
            Username: <input name="username"><br>
            Password: <input name="password" type="password"><br>
            <button type="submit">Login</button>
        </form>
    `);
});

// ================= SECURE LOGIN (SQL FIXED) =================
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    const query = "SELECT * FROM users WHERE username = ? AND password = ?";

    db.get(query, [username, password], (err, user) => {
        if (err) {
            console.log(err);
            return res.send("❌ Error occurred");
        }

        if (user) {
            res.send("✅ Login success");
        } else {
            res.send("❌ Login failed");
        }
    });
});

// ================= CSRF SECURE FORM =================
app.get('/form', csrfProtection, (req, res) => {
    res.send(`
        <h2>CSRF Protected Form</h2>
        <form method="POST" action="/process">
            <input type="hidden" name="_csrf" value="${req.csrfToken()}">
            <input type="text" name="data" placeholder="Enter something">
            <button type="submit">Submit</button>
        </form>
    `);
});

// ================= CSRF PROTECTED POST =================
app.post('/process', csrfProtection, (req, res) => {
    res.send("✅ CSRF Protected Request Successful");
});

// ================= OPTIONAL BCRYPT EXAMPLE =================
// (ONLY DEMO - not used in login here)
const hashedPassword = bcrypt.hashSync("1234", 10);
console.log("Hashed password example:", hashedPassword);

// ================= START SERVER =================
app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});
