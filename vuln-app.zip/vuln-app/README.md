ETHICAL HACKING REPORT (Week 5)
🔹 1. Introduction

This project focuses on understanding web application security vulnerabilities through ethical hacking techniques. The main objective is to identify, exploit, and fix common security flaws in a Node.js web application in a controlled test environment.

The security testing was performed to analyze risks such as SQL Injection and CSRF attacks, and to implement proper security measures to protect the application.

🔹 2. Tools Used

The following tools were used during the security testing process:

🐧 Kali Linux — for penetration testing environment
🧪 SQLMap — for detecting and exploiting SQL Injection
🕷️ Burp Suite — for intercepting and testing CSRF attacks
🟢 Node.js — backend development environment
🗄️ SQLite — database used in the application
🔹 3. Vulnerabilities Found
🔥 3.1 SQL Injection

A SQL Injection vulnerability was found in the login form due to improper handling of user input.

Affected Page: Login form
Issue: User input was directly inserted into SQL query
Payload Used:
' OR 1=1 --
Impact:
Authentication bypass
Unauthorized access to system
🔥 3.2 Cross-Site Request Forgery (CSRF)

The application was vulnerable to CSRF attacks before implementing protection.

Issue: No CSRF token validation in forms
Impact:
Attacker could perform unauthorized actions on behalf of logged-in users
🔹 4. Exploitation

The vulnerabilities were exploited in a controlled environment:

SQL Injection was tested manually and confirmed using SQLMap
SQLMap was able to detect injection and extract database information
Login bypass was successfully achieved using malicious payloads
CSRF attack was tested using Burp Suite by intercepting and modifying requests
🔹 5. Fixes Applied
✅ 5.1 SQL Injection Fix

The vulnerability was fixed using Prepared Statements:

User input is now passed as parameters
SQL queries are no longer directly concatenated

✔ Result: SQL Injection attack blocked successfully

✅ 5.2 CSRF Fix

CSRF protection was implemented using:

csurf middleware
Unique CSRF tokens added to all forms
Server validates token before processing requests

✔ Result: Unauthorized requests are now rejected

🔹 6. Conclusion

The application was successfully tested for common web security vulnerabilities. SQL Injection and CSRF vulnerabilities were identified and fixed using secure coding practices.

After applying security improvements:

The system is now protected against SQL Injection attacks
CSRF attacks are prevented using token-based validation
Overall application security has been significantly improved
